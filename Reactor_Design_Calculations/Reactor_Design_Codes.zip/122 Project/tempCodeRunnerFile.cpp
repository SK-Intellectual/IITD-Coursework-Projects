  // for(int l=0;l<=T;l++){
    //     out1<<l<<" "<<conc_time_data[l]<<endl;
    // }
    