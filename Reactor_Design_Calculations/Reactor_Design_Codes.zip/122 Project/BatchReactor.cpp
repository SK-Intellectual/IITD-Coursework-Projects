#include<iostream>
#include<iomanip>
#include<fstream>
#include<cmath>
#include<vector>
using namespace std;

double t=0;

vector<double> conv(100);
vector<double> timedata(100);


double calc_time_batch1(int n, double na0, double v, double k, double x){
    for(int k=0;k<100;k++){
        timedata[k]=0;
    }
    double ca0 = na0/v;
    if(n == 0){
        t = (na0/(v*k))*x;
        for(int p=1;p<100;p++){
            timedata[p] = (na0/(v*k))*conv[p];
        }
        } 
    else if (n == 1){
        t = ((1/k)*log(1/(1-x)));
        for(int p=1;p<100;p++){
            timedata[p] = ((1/k)*log(1/(1-conv[p])));
        }
        }
    else {
        t = (1/(k*(pow(ca0,n-1))))*(pow(1-x,1-n)-1)/(n-1);
        for(int p=1;p<100;p++){
            timedata[p] = (1/(k*(pow(ca0,n-1))))*(pow(1-conv[p],1-n)-1)/(n-1);
        }
        
    }
    return t;
}

int main(){
    cout<<"Enter order: ";
    int n; cin>>n;
    cout<<"Enter Initial Mole amount: ";
    double na0; cin >> na0;
    cout << "Enter volume of the reactor:(in litre) ";
    double v; cin >> v;
    cout << "Enter rate constant for the reaction: ";
    double k; cin >> k;
    cout<<"Enter required conversion: ";
    double x; cin>>x;
    conv[0]=0.0;
    for (int j = 1; j < 100; j++) {
        conv[j] = j / 100.0; // Scale the value from 0 to 1
    }
    calc_time_batch1(n, na0,v,k,x);
    double t0 = timedata[99]; //limit for time
    int T = floor(t0);
    
    double ca0=na0/v;
    vector <double> conc_time_data(1000);

    double step_size_t=T/1000.00;


    conc_time_data[0]=ca0;
    if(n!=1){
        for(double i =1; i<1000;i++){
            conc_time_data[i]=ca0*(pow((k*((i+1)*step_size_t)*pow(ca0,(n-1))*(n-1)+1),1/(1-n)));
        }
    }
    else{
        for(double i =1; i<1000;i++){
            conc_time_data[i]=ca0*pow(2.718281828459,(-1)*k*((i+1)*step_size_t));
        }  
    }
    
    cout<<"Time taken is : "<<t<<" seconds"<<endl;

    
    ofstream out("conv_time_data.txt"); //file to store the data of time and conversion
    ofstream out1("conc_time_data.txt"); //file to store the data of time and concentration

    timedata[0]=0.0;
    out<<conv[0]<<" "<<timedata[0]<<endl;
    for(int l=1;l<100;l++){
        out<<conv[l]<<"  "<<timedata[l]<<endl;
    }
    out1<<0<<" "<<ca0<<endl;
    for(int l=1;l<=1000;l++){
        out1<<l*step_size_t<<" "<<conc_time_data[l]<<endl;
    }
    
    
    out.close();
    out1.close();
    
    // string command =  "gnuplot -persist -e \""
    //                 "set xlabel 'Time';"
    //                 "set ylabel 'Conv';"
    //                 "plot 'conv_time_data.txt' with lines lc 'blue' title 'Curve'\"";
    // system(command.c_str());

    return 0;
}