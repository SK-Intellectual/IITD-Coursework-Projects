#include<iostream>
#include<iomanip>
#include<fstream>
#include<cmath>
#include<vector>
using namespace std;

double fx(double a,double s, double p, double x){
    return p*pow(((1+s*x)/(1-x)),a);
    }
int main(){
    ifstream in1("PBRin.txt");
    ofstream out("PBRout.txt");
    double a,b,c; // Stoichiometric Coordinates
    double fa0; // Enterinng Molar Flow Rate (in mol/sec)
    double v; // Volumetric rate of Reactor (in litres/sec)
    double k; // Reaction rate constant in SI
    double X; // Required Conversion
    double p0; // Initial pressure (in atm)
    double p; // Final pressure (in atm)
    in1>>a>>b>>c>>fa0>>v>>k>>X>>p0>>p;
    in1.close();
    
    double ca0= fa0*v;
    double cz = (fa0/k)*pow((p0/(p*ca0)),a);
    double L=(b+c-a)/a;

    double t=0;
    vector<double>x(500);

    for (int i=0; i<500;i++){
        x[i]=i*0.002*X;
    }

    out <<0.000<< "                                    " <<0.0000<< endl;
    for (int i=0;i<500;i++){
        t+=0.002/3.0*(fx(a,L,cz,x[i])+4*fx(a,L,cz,(x[i+1]+x[i])/2.0)+fx(a,L,cz,x[i+1]));
        out << t << "                                "<< fixed << setprecision(5)<< (i+1)*0.002  << endl;
    }
   
    // string command1 = "gnuplot -persist -e \""
    // "set xlabel 'x axis';"
    // "set ylabel 'y axis';"
    // "plot 'PBRout.txt' with linespoints lc rgb 'red' title 'Deflection'\"";
    // system(command1.c_str());
    
    // cout << a << ' ' << b << ' ' << c << ' ' << fa0 << ' ' << ca0 << ' ' << v << ' ' << k << ' ' << X << ' ' << p << ' ' << p0 << ' ' << L << ' ' << cz;
    out.close();
    return 0;
}