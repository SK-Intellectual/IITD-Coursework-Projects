#include<iostream>
#include<iomanip>
#include<fstream>
#include<cmath>
#include<vector>
using namespace std;

double fx(double a,double s, double x){
    return pow(((1+(s*x))/(1-x)),a);
}
int main(){
    ifstream in1("PBRin.txt");
    ofstream out("PBRout1.txt");
    double a,b,c; // Stoichiometric Coordinates
    double fa0; // Enterinng Molar Flow Rate (in mol/sec)
    double v; // Volume of Reactor (in litres)
    double k; // Reaction rate constant in SI
    double X; // Required Conversion
    double p0; // Initial pressure (in atm)
    double p; // Final pressure (in atm)
    in1>>a>>b>>c>>fa0>>v>>k>>X>>p0>>p;
    in1.close();
    
    double ca0= fa0*v;
    double cz = (fa0/k)*pow((p0/(p*ca0)),a);
    double L=(b+c-a)/a;

    double t=0;
    int no_of_datapts = 101;
    int N = no_of_datapts-1;
    vector<double>x(no_of_datapts);
    x[0] = 0.00; 
    double del_x = 0.01;

    //Matrix of Conversion points
    for(int i=1;i<no_of_datapts;i++){
        x[i] = (i)*del_x;
    }
    //Integrand Function Values Matrix
    vector<double>f(no_of_datapts);
    f[0]=0;
    for(int i=1;i<no_of_datapts;i++){
        f[i] = cz*(fx(a,L,x[i]));
    }
    //Weight of Catalyst Matrix for each conversion from 0 to 1
    vector<double>W(no_of_datapts);
    //Simpson's 1/3rd Rule
    double s1,s2;
    W[0]=0;
    for(int i=0;i<no_of_datapts;i++){
      s1=0,s2=0;
      for(int j=1;j<i+1;j+=2){
        s1 += f[j];
      }
      for(int k=2;k<i+1;k+=2){
        s2 += f[k];
      }
        W[i] = (x[i]-x[0])*(f[0]+f[i]+(4*s2)+(2*s1))/(3*(i));
    }
    

    // string command1 = "gnuplot -persist -e \""
    // "set xlabel 'x axis';"
    // "set ylabel 'y axis';"
    // "plot 'PBRout1.txt' with linespoints lc rgb 'green' title 'Weight of Catalyst'\"";
    // system(command1.c_str());
    
    out.close();
    return 0;
}