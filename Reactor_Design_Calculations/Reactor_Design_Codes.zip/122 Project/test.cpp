#include<iostream>
#include<cmath>
using namespace std;

int main(){
    cout<<pow(3,4);
    return 0;
}