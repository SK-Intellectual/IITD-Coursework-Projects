#include<iostream>
#include<iomanip>
#include<fstream>
#include<cmath>
#include<vector>
using namespace std;

int main(){
    bool const_flow_rate;
    bool Press_drop;
    double Ca0,v0,Fa0,k, epsilon, p,P,P0,X;
    vector<double>Ca(100);
    vector<double>V_matrix(100);
    double a,b,c;
    ifstream in1("Inflow.txt");
    in1>>a>>b>>c>>Fa0>>v0>>k>>P>>P0>>X;
    
    
    Ca0 = Fa0/v0;
    double delta = 1;
    Press_drop = true; // USER input

    if(Press_drop = true){
        p = P/P0;
    }else{
        P=P0;
        p=1;
    }

    epsilon = (b+c-a)*delta/a;
    double V_req;  //  Required volume of reactor for given conversion

    // double v = v0*(1+(epsilon*X))/p; //volume flow rate

    
    const_flow_rate = false;  // user input
    
    

    ofstream CX("CvsX.txt");
    ofstream VX("VvsX.txt");

    if(const_flow_rate == true) {

        V_req = (v0/k)*(log(1/(1-X))); 
        for(int i=0;i<100;i++){
            Ca[i] = Ca0*(1-(i*0.01));  //Conc data file
            V_matrix[i] = (v0/k)*(log(1/(1-(i*0.01))));  // Vol data file
            CX<<i*0.01<<" "<<Ca[i]<<endl;
            VX<<i*0.01<<" "<<V_matrix[i]<<endl;
        }

    }else{
        if(p==1){
            V_req = (v0/k)*(((1+epsilon)*(log(1/(1-X))))-(epsilon*X));
            for(int i=0;i<100;i++){
                Ca[i] = Ca0*(1-(i*0.01))*p/(1+(epsilon*(i*0.01)));  //Conc data file
                V_matrix[i] = (v0/k)*(((1+epsilon)*(log(1/(1-(i*0.01)))))-(epsilon*(i*0.01))); // Vol data file
                CX<<i*0.01<<" "<<Ca[i]<<endl;
                VX<<" "<<V_matrix[i]<<i*0.01<<endl; 
            }
        }else{
            V_req = (v0/k)*(((1+epsilon)*(log(1/(1-X))))-(epsilon*X));
            for(int i=0;i<100;i++){
                Ca[i] = Ca0*(1-(i*0.01))*p/(1+(epsilon*(i*0.01)));  //Conc data file
                V_matrix[i] = (v0/k)*(((1+epsilon)*(log(1/(1-(i*0.01)))))-(epsilon*(i*0.01))); // Vol data file
                CX<<i*0.01<<" "<<Ca[i]<<endl;
                VX<<" "<<V_matrix[i]<<i*0.01<<endl; 
            }

        }
        

    }

    

    string command =  "gnuplot -persist -e \""
                    "set xlabel 'Conv';"
                    "set ylabel 'Conc';"
                    "plot 'CvsX.txt' with lines lc 'blue' title 'Curve'\"";
    system(command.c_str());

    string command1 =  "gnuplot -persist -e \""
                    "set xlabel 'Vol';"
                    "set ylabel 'Conv';"
                    "plot 'VvsX.txt' with lines lc 'blue' title 'Curve'\"";
    system(command1.c_str());

    return 0;
}